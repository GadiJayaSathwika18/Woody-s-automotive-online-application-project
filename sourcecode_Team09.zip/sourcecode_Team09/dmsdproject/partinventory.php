<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "woodysdb";
$conn = new mysqli($servername, $username, $password, $dbname);

function returnFormLocation($conn) {
    $query = "SELECT * FROM `location`";
    $location = $conn->query($query);
    $html = "<h4>Inventory Location</h4>";
    if ($location->num_rows > 0) {
        while($row = $location->fetch_assoc()) {
            $html .= "<input type=\"radio\" name=\"locationid\" value=\"".$row["id"]."\">".$row["loc_address"]."<br>";
        }
    } 
    else {
        $html .= "0 results";
    }

    return $html;
}

echo "<h3>Parts Used</h3>";
echo "<form method=\"POST\" action=\"partupdate.php\">";
echo returnFormLocation($conn);
echo "
    <br>
    <label for=\"part\">Part</label>
    <input type=\"part\" name=\"part\"><br>
    <br>
    <input type=\"submit\" value=\"Submit Changes\">
</form>
<a href=\"employee.php\">Go back</a>";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 20px;
        }

        h3 {
            color: #333;
            margin-top: 0;
        }

        form {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }

        input[type="radio"] {
            margin-right: 5px;
        }

        input[type="text"] {
            padding: 5px;
            width: 200px;
        }

        input[type="submit"] {
            background-color: #0066cc;
            color: #fff;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0052a2;
        }

        a {
            color: #0066cc;
            text-decoration: none;
        }
    </style>
</head>
<body>
</body>
</html>

<?php
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
       /* center the form */
form {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    margin-top: 50px;
    margin-bottom: 50px;
}

/* add space between the heading and the form */
h1 {
    margin-top: 50px;
}

/* style the input fields and labels */
input[type="text"],
input[type="email"],
input[type="tel"] {
    padding: 10px;
    border: none;
    border-radius: 5px;
    box-shadow: 0 0 5px rgba(0,0,0,0.3);
    margin-bottom: 20px;
    width: 100%;
    max-width: 350px;
}

label {
    display: block;
    margin-bottom: 10px;
    font-weight: bold;
}

/* style the submit button */
input[type="submit"] {
    padding: 10px;
    border: none;
    border-radius: 5px;
    box-shadow: 0 0 5px rgba(0,0,0,0.3);
    background-color: #4285f4;
    color: white;
    font-weight: bold;
    cursor: pointer;
    transition: background-color 0.2s ease;
}

input[type="submit"]:hover {
    background-color: #3367d6;
}

/* style the form container */
body {
    background-color: #f1f1f1;
}

/* style the form header */
header {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
    background-color: #ffffff;
    box-shadow: 0 0 5px rgba(0,0,0,0.3);
}

/* style the form logo */
.logo {
    height: 40px;
    margin-right: 10px;
}

/* style the form title */
.form-title {
    font-size: 24px;
    font-weight: bold;
    color: #444444;
}

/* style the form fields */
.form-field {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    margin: 20px;
}

.form-field label {
    margin-bottom: 5px;
    font-weight: normal;
    color: #444444;
}

.form-field input {
    margin-bottom: 15px;
}

/* style the form input icons */
.form-field input[type="text"]:before,
.form-field input[type="email"]:before,
.form-field input[type="tel"]:before {
    font-family: 'Material Icons';
    font-weight: normal;
    font-style: normal;
    font-size: 24px;
    color: #4285f4;
    display: inline-block;
    text-decoration: none;
    content: 'input';
    margin-right: 5px;
}

/* style the form input fields */
.form-field input[type="text"],
.form-field input[type="email"],
.form-field input[type="tel"] {
    width: 100%;
    max-width: 350px;
    padding: 10px 10px 10px 40px;
    border: none;
    border-radius: 5px;
    box-shadow: 0 0 5px rgba(0,0,0,0.3);
}
</style>
</head>
<body>
    <a href="index.php">Home</a>
    <h1>Customer login</h1>
    <form method="POST" action="customerhome.php">
        <p><label for="id">Customer ID</label>
        <input type="number" name="id"></p>
        <p><label for="email">Email ID</label>
        <input type="email" name="email"></p>
        <input type="submit" value="Go to Customer Page">
        <a href="customer.php">register</a>
    </form>

</body>
</html>
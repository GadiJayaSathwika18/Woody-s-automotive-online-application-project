<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "woodysdb";
$conn = new mysqli($servername, $username, $password, $dbname);
if(isset($_POST['update'])) {
    $fname = mysqli_real_escape_string($conn, $_POST['fname']);
    $minit = mysqli_real_escape_string($conn, $_POST['minit']);
    $lname = mysqli_real_escape_string($conn, $_POST['lname']);
    $haddress = mysqli_real_escape_string($conn, $_POST['haddress']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $creditcard = mysqli_real_escape_string($conn, $_POST['creditcard']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);

    $sql = "UPDATE `customer` SET `fname`='$fname',`minit`='$minit',`lname`='$lname',`haddress`='$haddress',`phone`='$phone', `creditcard`='$creditcard',`email`='$email' WHERE `id`='$_SESSION[id]'";
    $result = mysqli_query($conn, $sql);

    if($result) {
        // Success message
        $_SESSION['success'] = "Customer details updated successfully";
    } else {
        // Error message
        $_SESSION['error'] = "Error updating Customer details: " . mysqli_error($conn);
    }

    // Redirect back to the same page
    header("location: editprofile.php");
    exit();
}

$sql = "SELECT * FROM `customer` WHERE `id`='$_SESSION[id]'";
$result = mysqli_query($conn, $sql);
$customer = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Customer Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Edit Customer Profile</h1>
        <form action="" method="post">
            <div class="mb-3">
                <label for="fname" class="form-label">First Name</label>
                <input type="text" class="form-control" id="fname" name="fname" value=<?php echo $customer['fname']; ?> required>
            </div>
            <div class="mb-3">
                <label for="minit" class="form-label">Middle Name</label>
                <input type="text" class="form-control" id="minit" name="minit" value=<?php echo $customer['minit']; ?> required>
            </div>
            <div class="mb-3">
                <label for="lname" class="form-label">Last Name</label>
                <input type="text" class="form-control" id="lname" name="lname" value=<?php echo $customer['lname']; ?> required>
            </div>
            <div class="mb-3">
                <label for="haddress" class="form-label">Home Address</label>
                <input type="text" class="form-control" id="haddress" name="haddress" value="<?php echo  $customer['haddress']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="phone" class="form-label">Phone Number</label>
                <input type="tel" class="form-control" id="phone" name="phone" value=<?php echo $customer['phone']; ?> required>
            </div>
            <div class="mb-3">
                        <label for="creditcard" class="form-label">Credit Card Number</label>
            <input type="text" class="form-control" id="creditcard" name="creditcard" value=<?php echo $customer['creditcard']; ?> required>
        </div>
        <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" value=<?php echo $customer['email']; ?> required>
            </div>
        <button type="submit" class="btn btn-primary" name="update">Update</button>
        <a href='index.php' class='btn btn-secondary'>Cancel</a>
    </form>

    <?php if(isset($_SESSION['success'])): ?>
        <div class="alert alert-success mt-3">
            <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
        </div>
    <?php endif; ?>

    <?php if(isset($_SESSION['error'])): ?>
        <div class="alert alert-danger mt-3">
            <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.min.js"></script>
</body>
</html>


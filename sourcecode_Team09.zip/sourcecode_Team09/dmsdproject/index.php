<?php
function display_empty_form() {
    print('<form method="POST" action="welcome.php">
    Enter your name: <input type="text" name="user_name">
    <br>
    <input type="submit" value="Submit Name">
    </form>');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <style>
 body {
  font-family: Arial, sans-serif;
  background-color: #f1f1f1;
  margin: 0;
  padding: 0;
}

h1 {
  text-align: center;
  margin-top: 40px;
  color: #333;
}

a {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 200px;
  height: 50px;
  margin: 20px auto;
  color: white;
  background-color: #007bff;
  border-radius: 4px;
  font-size: 16px;
  text-decoration: none;
  transition: background-color 0.3s ease;
}

a:hover {
  background-color: #0056b3;
}

.container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 70%;
  margin-top: 40px;
}
 
    </style>
</head>
<body>
    <h1>Woody's Automotive Services</h1>
    <a href="customer.php">Customer Register page</a>
    <br><br>
    <a href="customerlogin.php">Customer login Page</a>
    <br><br>
    <a href="employee.php">Employee Page</a>
</body>
</html>

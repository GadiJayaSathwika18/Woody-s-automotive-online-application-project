<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 20px;
        }

        h1 {
            color: #333;
            margin-top: 0;
        }

        a {
            color: #0066cc;
            text-decoration: none;
        }

        .order-details {
            margin-bottom: 20px;
        }

        .order-details p {
            margin: 0;
        }

        .order-details strong {
            font-weight: bold;
        }
    </style>
</head>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "";

$dbname = "woodysdb";
$vin = $_POST["vin"];
$date = $_POST["date"];
$location = $_POST["location"];
$vehicle_type = $_POST["vehicle_type"];
$skill_names = $_POST["skill"];
$cust_id = $_POST["cust_id"];

$conn = new mysqli($servername, $username, $password, $dbname);
$display_order_query = "SELECT `id`, `svc_type`, `vehicle_type`, `skill_id`, `price` FROM `servicesoffered` WHERE `svc_type` = \"$skill_names\" AND `vehicle_type` = \"$vehicle_type\"";
$get_loc_id = "SELECT `id` FROM `location` WHERE `loc_address` = \"$location\"";
$loc_id = $conn->query($get_loc_id);
$loc_id = $loc_id->fetch_assoc()["id"];
$services = $conn->query($display_order_query);
$base_price = 0;
$row = $services->fetch_assoc();
$service_id = $row["id"];
echo "Vehicle Type Is: ".$row["vehicle_type"];
echo "<br>";
echo "<br>You ordered the following service: ";
echo "Service: ".$row["svc_type"]." | Price: ". $row["price"];
echo "<br>";
$base_price = $base_price + $row["price"];
echo "<br>Your base price is: $".$base_price. " Labor is not included.";
echo "<br>";
echo "<br>Appointment date: " . $date;
echo "<br>";
echo "<br><a href=\"index.php\">Return</a>";


$appt_insert = "INSERT INTO `appointment` (`appt_date`, `loc_id`, `cust_id`, `vin`)
VALUES  ($date, $loc_id, $cust_id, $vin)";
$conn->query($appt_insert);
$appt_id = $conn->insert_id;
$appt_date_update = "UPDATE `appointment` SET appt_date = '$date' WHERE id = $appt_id";
$conn->query($appt_date_update);

$inv_insert = "INSERT INTO `invoice` (`amount`)
VALUES  ($base_price)";
$conn->query($inv_insert);
$inv_id = $conn->insert_id;

$invdetails_insert = "INSERT INTO `invoicedetails` (`appt_id`, `service_id`, `invoice_id`, `price`)
VALUES  ($appt_id, $service_id, $inv_id, $base_price)";
$conn->query($invdetails_insert);

?>

</body>
</html>


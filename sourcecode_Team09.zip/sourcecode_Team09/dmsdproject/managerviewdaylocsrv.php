<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }
        th, td {
            text-align: left;
            padding: 8px;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        form {
            margin-top: 20px;
            width: 50%;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0px 2px 2px #ccc;
        }
        input[type="radio"], input[type="number"], input[type="submit"] {
            margin: 10px;
            padding: 5px;
            border-radius: 3px;
            border: 1px solid #ccc;
            font-size: 16px;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
        }
        a {
            display: block;
            margin-top: 20px;
        }
    </style>
</head>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "woodysdb";
$conn = new mysqli($servername, $username, $password, $dbname);
$location = $_POST["location"];
$startdate = $_POST["startdate"];
$enddate = $_POST["enddate"];
$servicetype = $_POST["service"];
$vehicletype = $_POST["vehicle_type"];
$query = "SELECT `invoice_id`, `appt_date`, invoicedetails.price, `loc_address`, `vin`, `vehicle_type`, `svc_type`, `status` FROM `appointment`, `invoicedetails`, `location`, `servicesoffered` WHERE invoicedetails.service_id = servicesoffered.id AND invoicedetails.appt_id = appointment.id AND appointment.loc_id = location.id AND `vehicle_type` = '$vehicletype' AND `svc_type` = '$servicetype' AND `status` = 'Paid' AND`loc_address` = \"$location\" AND `appt_date` >= '$startdate' AND `appt_date` <= '$enddate' ORDER BY `invoice_id`";
$appts = $conn->query($query);
$sum = 0;
echo "<table>
        <tr>
        <th>Invoice Number</th>
        <th>Date</th>
        <th>Location</th>
        <th>VIN</th>
        <th>Vehicle Type</th>
        <th>Service</th>
        <th>Status</th>
        <th>Price</th>
        </tr>";
while($row = $appts->fetch_assoc()) {
echo "<tr>
        <td>".$row["invoice_id"]."</td>
        <td>".$row["appt_date"]."</td>
        <td>".$row["loc_address"]."</td>
        <td>".$row["vin"]."</td>
        <td>".$row["vehicle_type"]."</td>
        <td>".$row["svc_type"]."</td>
        <td>".$row["status"]."</td>
        <td>$".$row["price"]."</td>
</tr>";
$sum = $sum + $row["price"];
}
echo "</table>";
echo "<br>";
echo "Total Revenue: $" . $sum;
echo "<br><br><a href=\"employee.php\">Go back</a>";


?>
</body>
</html>

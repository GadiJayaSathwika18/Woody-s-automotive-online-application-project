<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 20px;
        }

        h1 {
            color: #333;
            margin-top: 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        a {
            color: #0066cc;
            text-decoration: none;
        }

        form {
            margin-top: 20px;
        }

        label {
            display: block;
            margin-bottom: 10px;
        }

        input[type="text"],
        input[type="date"],
        input[type="submit"] {
            margin-bottom: 10px;
            padding: 5px;
            width: 200px;
        }
    </style>
</head>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "woodysdb";
$conn = new mysqli($servername, $username, $password, $dbname);

$cust_id = $_POST["cust_id"];
echo "<a href=\"customer.php\">return</a>";

$query = "SELECT `invoice_id`, `appt_date`, invoicedetails.price, `loc_address`, `vin`, `vehicle_type`, `svc_type`, `status` FROM `appointment`, `invoicedetails`, `location`, `servicesoffered` WHERE invoicedetails.service_id = servicesoffered.id AND invoicedetails.appt_id = appointment.id AND appointment.loc_id = location.id AND `cust_id` = \"$cust_id\"";
$appts = $conn->query($query);
echo "<table>
        <tr>
        <th>Invoice Number</th>
        <th>Date</th>
        <th>Location</th>
        <th>VIN</th>
        <th>Vehicle Type</th>
        <th>Service</th>
        <th>Status</th>
        <th>Price</th>
        </tr>";
while($row = $appts->fetch_assoc()) {
echo "<tr>
        <td>".$row["invoice_id"]."</td>
        <td>".$row["appt_date"]."</td>
        <td>".$row["loc_address"]."</td>
        <td>".$row["vin"]."</td>
        <td>".$row["vehicle_type"]."</td>
        <td>".$row["svc_type"]."</td>
        <td>".$row["status"]."</td>
        <td>$".$row["price"]."</td>
</tr>";
}
echo "</table>";

echo "<h1>Payment</h1>";
echo "<form method=\"POST\" action=\"paid.php\">
<label for=\"id\">Invoice Number</label>
<input type=\"text\" name=\"id\"><br>
<input type=\"date\" name=\"date\" id=\"today\" value=\"".date("Y-m-d")."\" readonly><br>
<input type=\"submit\" value=\"Pay\">
</form>";
?>

<script>
    document.getElementById('today').value = moment().format('YYYY-MM-DD');
    </script>
</body>
</html>
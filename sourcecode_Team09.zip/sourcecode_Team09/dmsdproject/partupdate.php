<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "woodysdb";
$conn = new mysqli($servername, $username, $password, $dbname);

$partname = $_POST["part"];
$locationid = $_POST["locationid"];
$getpartidquery = "SELECT * FROM `part` WHERE part_name = '$partname'";
$parts = $conn->query($getpartidquery);
$partid = $parts->fetch_assoc()["id"];

$query = "UPDATE `inventory` SET quantity = quantity - 1 WHERE part_id = '$partid' AND loc_id = '$locationid'";
$conn->query($query);
echo "Parts have been updated.<br>";


$queryparts = "SELECT * FROM `part`, `inventory`, `location` WHERE location.id = inventory.loc_id AND inventory.part_id = part.id";
$partsresult = $conn->query($queryparts);

echo "<h3>Part List</h3>
<table>
    <tr>
        <th>Part ID</th>
        <th>Part Name</th>
        <th>Location</th>
        <th>Quantity</th>
        <th>Price</th>
    </tr>";
while($row = $partsresult->fetch_assoc()) {
    echo "<tr>
            <td>".$row["part_id"]."</td>
            <td>".$row["part_name"]."</td>
            <td>".$row["loc_address"]."</td>
            <td>".$row["quantity"]."</td>
            <td>".$row["price"]."</td>
          </tr>";
}
echo "</table><br>";
echo "<br><a href=\"index.php\">Return</a>";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 20px;
        }

        h3 {
            color: #333;
            margin-top: 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        a {
            color: #0066cc;
            text-decoration: none;
        }
    </style>
</head>
<body>
</body>
</html>

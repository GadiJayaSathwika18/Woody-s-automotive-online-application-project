<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }
        th, td {
            text-align: left;
            padding: 8px;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        form {
            margin-top: 20px;
            width: 50%;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0px 2px 2px #ccc;
        }
        input[type="radio"], input[type="number"], input[type="submit"] {
            margin: 10px;
            padding: 5px;
            border-radius: 3px;
            border: 1px solid #ccc;
            font-size: 16px;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
        }
        a {
            display: block;
            margin-top: 20px;
        }
    </style>
</head>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "woodysdb";
$conn = new mysqli($servername, $username, $password, $dbname);
$startdate = $_POST["startdate"];
$enddate = $_POST["enddate"];

$query = "SELECT `loc_address`, SUM(`price`) FROM `appointment`, `invoicedetails`, `location` WHERE invoicedetails.appt_id = appointment.id AND appointment.loc_id = location.id AND `status` = 'Paid' AND `appt_date` >= '$startdate' AND `appt_date` <= '$enddate' GROUP BY `loc_address`  ORDER BY SUM(`price`) DESC";
$locations = $conn->query($query);
echo "Showing revenue between ".$startdate. " and ".$enddate;
echo "<table>
        <tr>
        <th>Location</th>
        <th>Revenue</th>
        </tr>";
while($row = $locations->fetch_assoc()) {
echo "<tr>
        <td>".$row["loc_address"]."</td>
        <td>$".$row["SUM(`price`)"]."</td>
</tr>";
}
echo "</table><br>";
echo "<a href=\"employee.php\">Go back</a>";

?>

    

</body>
</html>
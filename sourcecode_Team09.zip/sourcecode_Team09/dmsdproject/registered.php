<?php
$servername = "localhost";
$username = "root";
$password = "";

$dbname = "woodysdb";
$fname = $_POST["fname"];
$minit = $_POST["minit"];
$lname = $_POST["lname"];
$phone = $_POST["phone"];
$haddress = $_POST["haddress"];
$creditcard = $_POST["creditcard"];
$email = $_POST["email"];


//register query and return id
$conn = new mysqli($servername, $username, $password, $dbname);
$query = "INSERT INTO `customer` (`fname`, `minit`, `lname`, `haddress`, `phone`, `creditcard`, `email`)
VALUES  ('$fname', '$minit', '$lname', '$haddress', '$phone', '$creditcard', '$email');";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Registered</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 20px;
        }

        h1 {
            color: #333;
            margin-top: 0;
        }

        a {
            color: #0066cc;
            text-decoration: none;
        }

        .order-details {
            margin-bottom: 20px;
        }

        .order-details p {
            margin: 0;
        }

        .order-details strong {
            font-weight: bold;
        }
    </style>
</head>
<body>
<?php
if ($conn->query($query) === TRUE) {
    $lastid = $conn->insert_id;
    echo "Successfully created an account<br>";
    echo "Your customer id is: " . $lastid;
    echo "<br>Please remember your customer id.";
  }
  else {
    echo "Fail: " . $conn->error;
  }
  ?>
  <br>
  <a href="customer.php">Return to customer page</a>
</body>
</html>
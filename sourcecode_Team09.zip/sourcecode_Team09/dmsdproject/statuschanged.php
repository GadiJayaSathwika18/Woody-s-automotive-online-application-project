<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manager View</title>

    <!-- CSS Reset -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css">

    <!-- Custom CSS -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            color: #333;
            margin: 0;
            padding: 20px;
        }

        h1 {
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }

        form {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="number"],
        input[type="submit"] {
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            font-size: 14px;
        }

        input[type="number"] {
            width: 200px;
            margin-bottom: 10px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: #fff;
            cursor: pointer;
        }

        a {
            color: #065fd4;
            text-decoration: none;
            display: inline-block;
            margin-right: 10px;
            padding: 5px;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "woodysdb";
$conn = new mysqli($servername, $username, $password, $dbname);

$id = $_POST["id"];
$status = $_POST["status"];
$price = $_POST["price"];

$query = "UPDATE `invoice` SET amount = '$price' WHERE id = '$id'";
if($conn->query($query) === TRUE) {
    echo "<br>Price has been changed to ".$price. " for invoice ".$id;
}
$query = "UPDATE `invoicedetails` SET price = '$price', status = '$status' WHERE invoice_id = '$id'";
if($conn->query($query) === TRUE) {
    echo "<br>Status has been changed to ".$status. " for invoice ".$id;
}

echo "<br><a href=\"partinventory.php\">Edit Part Inventory</a>";
echo "<br><a href=\"employee.php\">Go back</a>";


?>

</body>
</html>
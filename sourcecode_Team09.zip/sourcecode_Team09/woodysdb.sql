-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 27, 2023 at 04:02 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `woodysdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(6) UNSIGNED NOT NULL,
  `appt_date` date NOT NULL,
  `loc_id` int(6) UNSIGNED NOT NULL,
  `cust_id` int(6) UNSIGNED NOT NULL,
  `vin` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `appt_date`, `loc_id`, `cust_id`, `vin`) VALUES
(1, '2023-04-27', 3, 1, '111111'),
(2, '2023-04-15', 5, 2, '211111'),
(3, '2023-04-23', 4, 3, '311111'),
(4, '2023-04-13', 2, 4, '411111'),
(5, '2023-04-17', 1, 5, '511111'),
(6, '2023-04-20', 3, 6, '611111'),
(7, '2023-04-21', 3, 7, '711111'),
(8, '2023-04-23', 4, 8, '811111'),
(9, '2023-04-25', 4, 9, '911111'),
(10, '2023-04-27', 5, 10, '101111'),
(11, '2023-04-27', 5, 11, '110111'),
(12, '2023-04-27', 2, 12, '120111'),
(13, '2023-04-27', 5, 13, '130111'),
(14, '2023-04-26', 2, 14, '140111'),
(15, '2023-04-27', 3, 15, '150111'),
(16, '2023-04-27', 1, 16, '160111'),
(17, '2023-04-27', 3, 17, '170111'),
(18, '2023-04-27', 1, 18, '180111'),
(19, '2023-04-27', 1, 18, '182111'),
(20, '2023-04-27', 3, 1, '111111'),
(21, '2023-04-28', 3, 1, '111111'),
(22, '2023-04-27', 3, 1, '121111'),
(23, '2023-04-27', 5, 2, '211111'),
(24, '2023-04-27', 4, 3, '311111'),
(25, '2023-04-27', 3, 17, '172111'),
(28, '2023-04-28', 3, 2, '211111'),
(29, '2023-04-27', 1, 1, '111111'),
(30, '2023-04-27', 1, 1, '111111'),
(31, '2023-04-27', 1, 1, '111111'),
(32, '2023-04-27', 1, 1, '111111'),
(33, '2023-04-27', 1, 1, '111111'),
(34, '2023-04-26', 1, 1, '3000');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(6) UNSIGNED NOT NULL,
  `fname` varchar(30) NOT NULL,
  `minit` char(1) DEFAULT NULL,
  `lname` varchar(30) NOT NULL,
  `haddress` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `creditcard` varchar(20) NOT NULL,
  `email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `fname`, `minit`, `lname`, `haddress`, `phone`, `creditcard`, `email`) VALUES
(1, 'John', 'S', 'Smith', '816 Washington Ave, Hoboken, NJ', '2015551822', '1234123412341234', 'johnsmith@example.com'),
(2, 'Jane', 'r', 'Doe', '51 Franklin Rd, East Brunswick, NJ', '201555816209', '2345234523452345', 'janedow@example.com'),
(3, 'Mark', 'S', 'Hale', '321 Moat Dr, Paramus, NJ', '2015558261', '3456345634563456', 'markhale@example.com'),
(4, 'Sam', 'B', 'Roberts', '61 Englewood St, Trenton, NJ', '2015557162', '4567456745674567', 'samroberts@example.com'),
(5, 'Jay', NULL, 'Dale', '12 Broad St, Newark, NJ', '2015557281', '5678567856785678', 'jaydale@example.com'),
(6, 'Mario', 'A', 'Fleming', '61 Morleys Green, Hoboken, NJ', '2015557150', '1111111111111111', 'mariofleming@example.com'),
(7, 'Jenny', 'B', 'Hardy', '61 Meadowsweet Town, Hoboken, NJ', '2015557151', '2222222222222222', 'jennyhardy@example.com'),
(8, 'Naomi', 'C', 'Norman', '61 Mallory Garden, Paramus, NJ', '2015557152', '3333333333333333', 'naominorman@example.com'),
(9, 'Herman', 'D', 'Bradshaw', '61 Mackenzie Common, Paramus, NJ', '2015557153', '4444444444444444', 'hermanbradshaw@example.com'),
(10, 'Willie', 'E', 'Winn', '61 Mortonhall Park Green, East Brunswick, NJ', '2015557154', '5555555555555555', 'williewinn@example.com'),
(11, 'Margaret', 'F', 'Choi', '61 Manor Close, East Brunswick, NJ', '2015557155', '6666666666666666', 'margaretchoi@example.com'),
(12, 'Edmund', 'G', 'Whalen', '61 The Croft, Trenton, NJ', '2015557156', '7777777777777777', 'edmundwhalen@example.com'),
(13, 'Mike', 'H', 'Bryant', '61 Primrose St, East Brunswick, NJ', '2015557157', '8888888888888888', 'mikebryant@example.com'),
(14, 'Jonathan', 'I', 'Rangel', '61 Jubilie Rd, Trenton, NJ', '2015557158', '9999999999999999', 'jonathanrangel@example.com'),
(15, 'Connie', 'J', 'Owen', '61 Willow St, Hoboken, NJ', '2015557159', '1212121212121212', 'connieowen@example.com'),
(16, 'Hal', 'K', 'Murry', '61 Swift St, Newark, NJ', '2015557160', '2323232323232323', 'halmurry@example.com'),
(17, 'Deb', 'L', 'Schneider', '61 Byron Ave, Hoboken, NJ', '2015557161', '3434343434343434', 'debschneider@example.com'),
(18, 'Keith', 'M', 'Ware', '61 Abe St, Newark, NJ', '2015557163', '4545454545454545', 'keithware@example.com'),
(19, 'aditya', 'e', 'sai', 'jones st', '9892878121', '3782829718287388', 'aditya123@gmail.com'),
(20, '', '', '', '', '', '', ''),
(21, 'micheal', '', 'renda', 'newark,nj', '2348791671', '1213143189', 'renda@gmail.com'),
(22, 'micheal', '', 'renda', 'newark,nj', '2348791671', '1213143189', 'renda@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `ssn` char(9) NOT NULL,
  `loc_id` int(6) UNSIGNED NOT NULL,
  `fname` varchar(30) NOT NULL,
  `minit` char(1) DEFAULT NULL,
  `lname` varchar(30) NOT NULL,
  `haddress` varchar(100) NOT NULL,
  `hire_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`ssn`, `loc_id`, `fname`, `minit`, `lname`, `haddress`, `hire_date`) VALUES
('113456789', 1, 'Michael', 'X', 'Hal', '123 S 9th St, Newark, NJ', '2023-04-10'),
('123456789', 2, 'Adrian', 'L', 'Chandler', '158 Franklin St, Trenton, NJ', '2023-03-10'),
('133456789', 3, 'Jaime', '', 'Ward', '151 Washington St, Hoboken, NJ', '2023-04-10'),
('143456789', 4, 'Antoinette', '', 'Holt', '16 Midland Ave, Paramus, NJ', '2023-03-10'),
('153456789', 5, 'Vera', 'V', 'Hogan', '30 Brookhill Rd, East Brunswick, NJ', '2023-03-10'),
('213456789', 1, 'Michelle', 'S', 'Dal', '114 Prince St, Newark, NJ', '2023-03-10'),
('223456789', 2, 'Tommy', '', 'Christian', '115 Melrose Ave, Trenton, NJ', '2023-04-10'),
('233456789', 3, 'Todd', '', 'Gregory', '791 Washington St, Hoboken, NJ', '2023-03-10'),
('243456789', 4, 'Everette', 'E', 'Peters', '203 Kendrick St, Paramus, NJ', '2023-04-10'),
('253456789', 5, 'Raymond', 'P', 'Padilla', '293 Timber Rd, East Brunswick, NJ', '2023-04-10'),
('313456789', 1, 'Fernando', '', 'Li', '58 Branch Ct, Newark, NJ', '2023-04-10'),
('323456789', 2, 'Traci', '', 'Baldwin', '48 Donald Dr, Trenton, NJ', '2023-03-10'),
('333456789', 3, 'Ramiro', '', 'Frazier', '80 Willow Ave, Hoboken, NJ', '2023-04-10'),
('343456789', 4, 'Taylor', 'O', 'Connel', '98 Paramus Rd, Paramus, NJ', '2023-03-10'),
('353456789', 5, 'Lourdes', '', 'Griffin', '100 Hilltop Blvd, East Brunswick, NJ', '2023-03-10'),
('413456789', 1, 'Manuel', '', 'Kreuger', '110 Newark St, Newark, NJ', '2023-03-10'),
('423456789', 2, 'Angelica', 'S', 'Jordan', '105 Van Camp Alley, Trenton, NJ', '2023-04-10'),
('433456789', 3, 'Wendell', '', 'Shepard', '467 Clinton St, Hoboken, NJ', '2023-03-10'),
('443456789', 4, 'Jeffrey', '', 'Hawkins', '162 Arundel Rd, Paramus, NJ', '2023-04-10'),
('453456789', 5, 'Alfred', '', 'Wilkins', '281 Claremont Ave, East Brunswick, NJ', '2023-04-10'),
('513456789', 1, 'Armando', 'K', 'North', '85 Avon Ave, Newark, NJ', '2023-04-10'),
('523456789', 2, 'Thomas', 'A', 'Darling', '219 Quincy Ave, Trenton, NJ', '2023-03-10'),
('533456789', 3, 'Ross', '', 'Jenkins', '77 Madison St, Hoboken, NJ', '2023-04-10'),
('543456789', 4, 'Pablo', '', 'Sparks', '212 Ring Rd, Paramus, NJ', '2023-03-10'),
('553456789', 5, 'Carmen', '', 'Gamble', '300 Woodlot Rd, East Brunswick, NJ', '2023-03-10');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` int(6) UNSIGNED NOT NULL,
  `quantity` int(6) NOT NULL,
  `part_id` int(6) UNSIGNED NOT NULL,
  `loc_id` int(6) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`id`, `quantity`, `part_id`, `loc_id`) VALUES
(1, 0, 1, 1),
(2, 20, 2, 1),
(3, 10, 3, 1),
(4, 5, 4, 1),
(5, 1, 1, 2),
(6, 22, 2, 2),
(7, 8, 3, 2),
(8, 6, 4, 2),
(9, 1, 1, 3),
(10, 22, 2, 3),
(11, 13, 3, 3),
(12, 2, 4, 3),
(13, 2, 1, 4),
(14, 21, 2, 4),
(15, 11, 3, 4),
(16, 7, 4, 4),
(17, 4, 1, 5),
(18, 16, 2, 5),
(19, 13, 3, 5),
(20, 2, 4, 5);

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `id` int(6) UNSIGNED NOT NULL,
  `amount` int(6) NOT NULL,
  `date_paid` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`id`, `amount`, `date_paid`) VALUES
(1, 20, '2023-04-26'),
(2, 200, '2023-04-15'),
(3, 200, '2023-04-23'),
(4, 100, '2023-04-13'),
(5, 200, '2023-04-17'),
(6, 200, '2023-04-20'),
(7, 200, '2023-04-21'),
(8, 200, '2023-04-23'),
(9, 200, '2023-04-25'),
(10, 200, NULL),
(11, 200, NULL),
(12, 200, NULL),
(13, 200, NULL),
(14, 200, '2023-04-26'),
(15, 200, NULL),
(16, 200, NULL),
(17, 200, NULL),
(18, 20, NULL),
(19, 200, NULL),
(20, 200, NULL),
(21, 200, NULL),
(22, 200, NULL),
(23, 200, '2023-04-26'),
(24, 200, NULL),
(25, 200, NULL),
(26, 100, '2023-04-26'),
(27, 50, NULL),
(28, 100, NULL),
(29, 50, '2023-04-27'),
(30, 50, NULL),
(31, 50, NULL),
(32, 50, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `invoicedetails`
--

CREATE TABLE `invoicedetails` (
  `appt_id` int(6) UNSIGNED NOT NULL,
  `service_id` int(6) UNSIGNED NOT NULL,
  `invoice_id` int(6) UNSIGNED NOT NULL,
  `price` float NOT NULL,
  `status` varchar(20) DEFAULT 'Waiting'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invoicedetails`
--

INSERT INTO `invoicedetails` (`appt_id`, `service_id`, `invoice_id`, `price`, `status`) VALUES
(1, 1, 1, 20, 'Paid'),
(2, 9, 2, 200, 'Paid'),
(3, 4, 3, 200, 'Paid'),
(4, 5, 4, 100, 'In Progress'),
(5, 20, 5, 200, 'Paid'),
(6, 5, 6, 200, 'Paid'),
(7, 7, 7, 200, 'Paid'),
(8, 13, 8, 200, 'Paid'),
(9, 6, 9, 200, 'Paid'),
(10, 7, 10, 200, 'Waiting'),
(11, 12, 11, 200, 'Waiting'),
(12, 14, 12, 200, 'Waiting'),
(13, 12, 13, 200, 'Waiting'),
(14, 17, 14, 200, 'Paid'),
(15, 16, 15, 200, 'In Progress'),
(16, 6, 16, 200, 'Completed'),
(17, 18, 17, 200, 'In Progress'),
(18, 5, 18, 20, 'Completed'),
(19, 6, 19, 200, 'In Progress'),
(20, 7, 20, 200, 'In Progress'),
(21, 4, 21, 200, 'Waiting'),
(22, 7, 22, 200, 'Completed'),
(23, 8, 23, 200, 'Paid'),
(24, 6, 24, 200, 'In Progress'),
(25, 7, 25, 200, 'Waiting for parts'),
(28, 9, 26, 100, 'Paid'),
(29, 1, 27, 50, 'In Progress'),
(30, 1, 28, 100, 'Completed'),
(31, 1, 29, 50, 'Paid'),
(32, 1, 30, 50, 'Waiting'),
(33, 1, 31, 50, 'Waiting'),
(34, 1, 32, 50, 'Waiting');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `id` int(6) UNSIGNED NOT NULL,
  `loc_address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`id`, `loc_address`) VALUES
(1, 'Newark, NJ'),
(2, 'Trenton, NJ'),
(3, 'Hoboken, NJ'),
(4, 'Paramus, NJ'),
(5, 'East Brunswick, NJ');

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `emp_ssn` char(9) NOT NULL,
  `salary` int(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`emp_ssn`, `salary`) VALUES
('113456789', 70000),
('123456789', 60000),
('133456789', 80000),
('143456789', 55000),
('153456789', 84000);

-- --------------------------------------------------------

--
-- Table structure for table `part`
--

CREATE TABLE `part` (
  `id` int(6) UNSIGNED NOT NULL,
  `part_name` varchar(20) NOT NULL,
  `price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `part`
--

INSERT INTO `part` (`id`, `part_name`, `price`) VALUES
(1, 'Engine', 300),
(2, 'Oil', 10),
(3, 'Tire', 100),
(4, 'Brake', 2000);

-- --------------------------------------------------------

--
-- Table structure for table `partusedinservice`
--

CREATE TABLE `partusedinservice` (
  `part_id` int(6) UNSIGNED NOT NULL,
  `service_id` int(6) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `partusedinservice`
--

INSERT INTO `partusedinservice` (`part_id`, `service_id`) VALUES
(1, 1),
(1, 8),
(1, 15),
(2, 5),
(2, 12),
(2, 19),
(3, 4),
(3, 11),
(3, 18),
(4, 3),
(4, 10),
(4, 17);

-- --------------------------------------------------------

--
-- Table structure for table `servicesoffered`
--

CREATE TABLE `servicesoffered` (
  `id` int(6) UNSIGNED NOT NULL,
  `svc_type` varchar(50) NOT NULL,
  `vehicle_type` varchar(25) NOT NULL,
  `skill_id` int(6) UNSIGNED NOT NULL,
  `price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `servicesoffered`
--

INSERT INTO `servicesoffered` (`id`, `svc_type`, `vehicle_type`, `skill_id`, `price`) VALUES
(1, 'Oil Change', 'Car', 1, 50),
(2, 'Front-end alignment', 'Car', 2, 75),
(3, 'Brake', 'Car', 3, 200),
(4, 'Tire repair and replacement', 'Car', 4, 60),
(5, 'Engine tune-up', 'Car', 5, 80),
(6, 'Vehicle computer diagnostic', 'Car', 6, 100),
(7, 'State vehicle inspection', 'Car', 7, 10),
(8, 'Oil Change', 'Van', 1, 75),
(9, 'Front-end alignment', 'Van', 2, 100),
(10, 'Brake', 'Van', 3, 300),
(11, 'Tire repair and replacement', 'Van', 4, 70),
(12, 'Engine tune-up', 'Van', 5, 150),
(13, 'Vehicle computer diagnostic', 'Van', 6, 100),
(14, 'State vehicle inspection', 'Van', 7, 10),
(15, 'Oil Change', 'Truck', 1, 50),
(16, 'Front-end alignment', 'Truck', 2, 100),
(17, 'Brake', 'Truck', 3, 400),
(18, 'Tire repair and replacement', 'Truck', 4, 100),
(19, 'Engine tune-up', 'Truck', 5, 200),
(20, 'Vehicle computer diagnostic', 'Truck', 6, 200),
(21, 'State vehicle inspection', 'Truck', 7, 20);

-- --------------------------------------------------------

--
-- Table structure for table `skill`
--

CREATE TABLE `skill` (
  `id` int(6) UNSIGNED NOT NULL,
  `skill_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `skill`
--

INSERT INTO `skill` (`id`, `skill_name`) VALUES
(1, 'Oil change'),
(2, 'Front-end alignment'),
(3, 'Brake'),
(4, 'Tire repair and replacement'),
(5, 'Engine tune-up'),
(6, 'Vehicle computer diagnostic'),
(7, 'State vehicle inspection');

-- --------------------------------------------------------

--
-- Table structure for table `technician`
--

CREATE TABLE `technician` (
  `emp_ssn` char(9) NOT NULL,
  `hourly_rate` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `technician`
--

INSERT INTO `technician` (`emp_ssn`, `hourly_rate`) VALUES
('213456789', 16.5),
('223456789', 15.5),
('233456789', 15.5),
('243456789', 18.5),
('253456789', 19.5),
('313456789', 15.5),
('323456789', 16.5),
('333456789', 14.5),
('343456789', 15.5),
('353456789', 15.5),
('413456789', 14.5),
('423456789', 15.5),
('433456789', 13.5),
('443456789', 14.5),
('453456789', 16.5),
('513456789', 13.5),
('523456789', 17.5),
('533456789', 17.5),
('543456789', 13.5),
('553456789', 18.5);

-- --------------------------------------------------------

--
-- Table structure for table `technician_skill`
--

CREATE TABLE `technician_skill` (
  `tech_ssn` char(9) NOT NULL,
  `skill_id` int(6) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `technician_skill`
--

INSERT INTO `technician_skill` (`tech_ssn`, `skill_id`) VALUES
('213456789', 1),
('213456789', 2),
('223456789', 1),
('223456789', 2),
('223456789', 3),
('223456789', 4),
('223456789', 5),
('223456789', 6),
('223456789', 7),
('233456789', 2),
('233456789', 4),
('233456789', 5),
('233456789', 6),
('243456789', 1),
('253456789', 2),
('313456789', 2),
('313456789', 3),
('323456789', 5),
('323456789', 6),
('333456789', 6),
('333456789', 7),
('343456789', 5),
('353456789', 1),
('413456789', 3),
('413456789', 4),
('423456789', 7),
('433456789', 3),
('443456789', 2),
('453456789', 3),
('513456789', 4),
('523456789', 4),
('533456789', 2),
('543456789', 6),
('553456789', 1);

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE `vehicle` (
  `vin` varchar(20) NOT NULL,
  `cust_id` int(6) UNSIGNED NOT NULL,
  `model` varchar(30) NOT NULL,
  `make_year` int(4) NOT NULL,
  `color` varchar(15) NOT NULL,
  `vehicle_type` varchar(20) NOT NULL,
  `manufacturer` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`vin`, `cust_id`, `model`, `make_year`, `color`, `vehicle_type`, `manufacturer`) VALUES
('', 1, '', 0, '', '', ''),
('101111', 10, 'Prius', 2017, 'Red', 'Car', 'Toyota'),
('110111', 11, 'Swift', 2009, 'Yellow', 'Van', 'Suzuki'),
('111111', 1, 'Camry', 2010, 'Blue', 'Car', 'Toyota'),
('120111', 12, 'Durango', 2013, 'Red', 'Van', 'Dodge'),
('121111', 1, 'Volt', 2022, 'Blue', 'Car', 'Chevrolet'),
('130111', 13, 'Enclave', 2014, 'Grey', 'Van', 'Buick'),
('140111', 14, 'Acadia', 2016, 'Red', 'Truck', 'GMC'),
('150111', 15, 'Sierra', 2020, 'Black', 'Truck', 'GMC'),
('160111', 16, 'Giula', 2022, 'Maroon', 'Car', 'Alfa Romeo'),
('170111', 17, 'X5', 2022, 'Black', 'Truck', 'BMW'),
('172111', 17, 'Focus', 2022, 'White', 'Car', 'Ford'),
('180111', 18, 'Passat', 2018, 'Grey', 'Car', 'Volkswagen'),
('182111', 18, 'TLX', 2022, 'Grey', 'Car', 'TLX'),
('21111', 2, 'crv', 2020, 'blue', 'Van', 'honda'),
('211111', 2, 'CRV', 2020, 'Black', 'Van', 'Honda'),
('3000', 1, 'model s', 2021, 'black', 'Car', 'BMW'),
('31111', 1, 'model s', 2021, 'black', 'Car', 'BMW'),
('311111', 3, 'Civic', 2010, 'Blue', 'Car', 'Honda'),
('40001', 1, 'G class', 2020, 'white', 'Car', 'Mercedes'),
('411111', 4, 'Y', 2020, 'Blue', 'Car', 'Tesla'),
('511111', 5, 'Discovery', 2012, 'Grey', 'Truck', 'Land Rover'),
('611111', 6, 'Hatchback', 2018, 'Grey', 'Car', 'MINI'),
('711111', 7, 'Q3', 2022, 'Blue', 'Car', 'Audi'),
('811111', 8, 'E-Pace', 2016, 'Black', 'Van', 'Jaguar'),
('911111', 9, 'Ibiza', 2018, 'Red', 'Car', 'Seat');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `loc_of_service` (`loc_id`),
  ADD KEY `cust_makes_appt` (`cust_id`),
  ADD KEY `vin_in_service` (`vin`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`ssn`),
  ADD KEY `employee_works_at_location` (`loc_id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `part_in_inventory` (`part_id`),
  ADD KEY `inventory_location` (`loc_id`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoicedetails`
--
ALTER TABLE `invoicedetails`
  ADD PRIMARY KEY (`appt_id`,`service_id`,`invoice_id`),
  ADD KEY `service_in_detail` (`service_id`),
  ADD KEY `invoice_in_detail` (`invoice_id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`emp_ssn`);

--
-- Indexes for table `part`
--
ALTER TABLE `part`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `partusedinservice`
--
ALTER TABLE `partusedinservice`
  ADD PRIMARY KEY (`part_id`,`service_id`),
  ADD KEY `service_has_id` (`service_id`);

--
-- Indexes for table `servicesoffered`
--
ALTER TABLE `servicesoffered`
  ADD PRIMARY KEY (`id`),
  ADD KEY `service_requires_skill` (`skill_id`);

--
-- Indexes for table `skill`
--
ALTER TABLE `skill`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `technician`
--
ALTER TABLE `technician`
  ADD PRIMARY KEY (`emp_ssn`);

--
-- Indexes for table `technician_skill`
--
ALTER TABLE `technician_skill`
  ADD PRIMARY KEY (`tech_ssn`,`skill_id`),
  ADD KEY `skill_for_tech` (`skill_id`);

--
-- Indexes for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`vin`),
  ADD KEY `cust_owns_vehicle` (`cust_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `part`
--
ALTER TABLE `part`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `servicesoffered`
--
ALTER TABLE `servicesoffered`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `skill`
--
ALTER TABLE `skill`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointment`
--
ALTER TABLE `appointment`
  ADD CONSTRAINT `cust_makes_appt` FOREIGN KEY (`cust_id`) REFERENCES `customer` (`id`),
  ADD CONSTRAINT `loc_of_service` FOREIGN KEY (`loc_id`) REFERENCES `location` (`id`),
  ADD CONSTRAINT `vin_in_service` FOREIGN KEY (`vin`) REFERENCES `vehicle` (`vin`);

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_works_at_location` FOREIGN KEY (`loc_id`) REFERENCES `location` (`id`);

--
-- Constraints for table `inventory`
--
ALTER TABLE `inventory`
  ADD CONSTRAINT `inventory_location` FOREIGN KEY (`loc_id`) REFERENCES `location` (`id`),
  ADD CONSTRAINT `part_in_inventory` FOREIGN KEY (`part_id`) REFERENCES `part` (`id`);

--
-- Constraints for table `invoicedetails`
--
ALTER TABLE `invoicedetails`
  ADD CONSTRAINT `appointment_in_detail` FOREIGN KEY (`appt_id`) REFERENCES `appointment` (`id`),
  ADD CONSTRAINT `invoice_in_detail` FOREIGN KEY (`invoice_id`) REFERENCES `invoice` (`id`),
  ADD CONSTRAINT `service_in_detail` FOREIGN KEY (`service_id`) REFERENCES `servicesoffered` (`id`);

--
-- Constraints for table `manager`
--
ALTER TABLE `manager`
  ADD CONSTRAINT `emp_is_manager` FOREIGN KEY (`emp_ssn`) REFERENCES `employee` (`ssn`);

--
-- Constraints for table `partusedinservice`
--
ALTER TABLE `partusedinservice`
  ADD CONSTRAINT `part_use_in_service` FOREIGN KEY (`part_id`) REFERENCES `part` (`id`),
  ADD CONSTRAINT `service_has_id` FOREIGN KEY (`service_id`) REFERENCES `servicesoffered` (`id`);

--
-- Constraints for table `servicesoffered`
--
ALTER TABLE `servicesoffered`
  ADD CONSTRAINT `service_requires_skill` FOREIGN KEY (`skill_id`) REFERENCES `skill` (`id`);

--
-- Constraints for table `technician`
--
ALTER TABLE `technician`
  ADD CONSTRAINT `emp_is_technician` FOREIGN KEY (`emp_ssn`) REFERENCES `employee` (`ssn`);

--
-- Constraints for table `technician_skill`
--
ALTER TABLE `technician_skill`
  ADD CONSTRAINT `skill_for_tech` FOREIGN KEY (`skill_id`) REFERENCES `skill` (`id`),
  ADD CONSTRAINT `tech_has_skill` FOREIGN KEY (`tech_ssn`) REFERENCES `technician` (`emp_ssn`);

--
-- Constraints for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD CONSTRAINT `cust_owns_vehicle` FOREIGN KEY (`cust_id`) REFERENCES `customer` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
